
<?php $__env->startSection('link-olah-data','active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row my-3">
        <div class="col-md-6 col-12">
            <div class="bg-white border border-2 shadow-sm p-3 rounded-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="h5 fw-bold p-0 m-0">Import Data</h5>
                    <a class="btn btn-primary btn-sm" id="btn-toggle" data-bs-toggle="collapse" href="#form-import" role="button" aria-expanded="false" aria-controls="collapseExample">Hide</a>
                </div>
                <hr class="my-2">
                <div class="collapse show" id="form-import">
                    <form action="<?php echo e(route('olahData.import')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-2">
                                    <label for="" class="form-label">Pilih Kegiatan</label>
                                    <select name="id_kegiatan" id="" class="form-select">
                                        <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kegiatan->id_kegiatan); ?>"><?php echo e($kegiatan->nama_kegiatan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['id_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-2">
                                    <label for="" class="form-label">Bulan</label>
                                    <select name="bulan" id="" class="form-select">
                                        <?php $__currentLoopData = $bulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bulan); ?>"><?php echo e($bulan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-2">
                                    <label for="" class="form-label">File Excel</label>
                                    <input type="file" name="excel" id="" class="form-control">
                                    <div class="form-text">
                                        <ul>
                                            <li>Format File Excel (.xls, .xlsx)</li>
                                            <li>Ukuran Maksimal Excel 2MB</li>
                                            <li>Untuk Tahun Wajib Diisi pada excel</li>
                                        </ul>
                                    </div>
                                    <?php $__errorArgs = ['excel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button class="btn-success btn btn-sm">Import</button>
                        </div>
                    </form>
                </div>
                
            </div>
        </div>
        <div class="col-md-12 col-12 mt-3">
            <div class="bg-white border border-2 shadow-sm p-3 rounded-3">
                <h5 class="h5 fw-bold">Lihat Data</h5>
                <hr class="my-2">
                <form action="<?php echo e(route('olahData.index')); ?>">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="mb-2">
                                <label for="" class="form-label">Pilih Kegiatan</label>
                                <select name="id_kegiatan" id="" class="form-select">
                                    <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kegiatan->id_kegiatan); ?>" <?php if(request('id_kegiatan')==$kegiatan->id_kegiatan): echo 'selected'; endif; ?>><?php echo e($kegiatan->nama_kegiatan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label for="" class="form-label">Bulan</label>
                                <select name="bulan" id="" class="form-select">
                                    <?php $__currentLoopData = $bulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bulan); ?>" <?php if(request('bulan')==$bulan): echo 'selected'; endif; ?>><?php echo e($bulan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label for="" class="form-label">Tahun</label>
                                <select name="tahun" id="" class="form-select">
                                    <?php $__currentLoopData = range(date('Y'),2022); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($year); ?>" <?php if(request('tahun')==$year): echo 'selected'; endif; ?>><?php echo e($year); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label for="" class="form-label">Nama</label>
                                <input type="text" class="form-control" name="nama" placeholder="Nama" value="<?php echo e(request('nama')); ?>">
                                <div class="form-text">*Besar Kecil Huruf Mempengaruhi</div>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button class="btn-primary btn btn-sm">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
                <hr class="my-2">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                            <?php if(count($searchResult)>0): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $searchResult->first(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <th><?php echo e(Str::title(str_replace('_',' ',$key))); ?></th>        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <th>No Found Record</th>
                                <?php endif; ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key=='foto'): ?>
                                            <td>
                                                <img src="<?php echo e(asset('storage/foto/'.$item)); ?>" alt="" class="img-thumbnail">
                                            </td>
                                        <?php else: ?>
                                            <td><?php echo e($item); ?></td>    
                                        <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td><a class="btn btn-sm btn-danger" href="<?php echo e(route('olahData.edit',$row->id_transaksi)); ?>">Foto</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td align="center" class="fw-bold">No Found Record</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if(count($searchResult)>0): ?>
                    <?php echo e($searchResult->links()); ?>

                <?php endif; ?>                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        var btnToggle = document.getElementById('btn-toggle')
        btnToggle.addEventListener('click',function(){
            btnToggle.innerHTML === "Hide" ? btnToggle.innerHTML='Show' : btnToggle.innerHTML='Hide'
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\share-sultan\resources\views/content/olahData/index.blade.php ENDPATH**/ ?>