<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
    <div class="container">
        <div class="row">
          <div class="col-md-6 offset-md-3 pt-3">
            <h2 class="text-center text-dark">Login</h2>
            <div class="card my-3">
                <form class="card-body cardbody-color p-3" method="POST" action="<?php echo e(route('auth')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                        <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3" width="200px" alt="profile">
                    </div>
                    <?php if(session('message')): ?>
                        <div class="alert alert-danger my-3" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>                    
                    <div class="mb-3">
                        <input type="text" class="form-control" name="user" id="Username" aria-describedby="emailHelp" placeholder="User Name">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-text text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <input type="password" class="form-control" name="password" id="password" placeholder="password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-text text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="text-center"><button type="submit" class="btn btn-color px-5 mb-5 w-100">Login</button></div>
                    <div id="emailHelp" class="form-text text-center mb-5 text-dark">
                        Not Registered? 
                        <a href="#" class="text-dark fw-bold"> Create anAccount</a>
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\PROJECT LARAVEL\sidak\resources\views/login.blade.php ENDPATH**/ ?>