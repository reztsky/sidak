
<?php $__env->startSection('link-olah-data','active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row my-3">
        <div class="col-md-5 col-12">
            <div class="bg-white border border-2 shadow-sm p-3 rounded-3">
                <dl class="row">
                    <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key=='id_transaksi') continue; ?>
                        <?php if($key=='id_kegiatan') continue; ?>
                        <?php if($key=='foto'): ?>
                            <dt class="col-md-4 col-sm-12 col-12"><?php echo e(Str::title(str_replace('_',' ',$key))); ?></dt>
                            <dd class="col-md-8 col-sm-12 col-12">
                                <img src="<?php echo e(asset('storage/foto/'.$value)); ?>" alt="" class="img-thumbnail" height="150px">
                            </dd>    
                        <?php else: ?>
                            <dt class="col-md-4 col-sm-12 col-12"><?php echo e(Str::title(str_replace('_',' ',$key))); ?></dt>
                            <dd class="col-md-8 col-sm-12 col-12"><?php echo e($value); ?></dd>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </dl>
            </div>
        </div>
        <div class="col-md-7 col-12">
            <div class="bg-white border border-2 shadow-sm p-3 rounded-3">
                <form action="<?php echo e(route('olahData.uploadFoto',request('id'))); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-2">
                                <label for="" class="form-label">Foto</label>
                                <input type="file" name="foto" id="" class="form-control">
                                <div class="form-text">
                                    Ukuran Foto Maksimal 2MB
                                </div>
                                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="form-text text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button class="btn btn-primary btn-sm">Upload</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
      
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT LARAVEL\sidak\resources\views/content/olahData/edit.blade.php ENDPATH**/ ?>