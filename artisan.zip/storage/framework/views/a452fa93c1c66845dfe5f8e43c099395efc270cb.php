<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><?php echo e(config('app.name')); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link <?php echo $__env->yieldContent('link-dashboard'); ?>" href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> 
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLevelTwo')): ?>
                        <a class="nav-link <?php echo $__env->yieldContent('link-olah-data'); ?>" href="<?php echo e(route('olahData.index')); ?>">Olah Data</a>
                    <?php endif; ?>
                    <a class="nav-link <?php echo $__env->yieldContent('link-active'); ?>" href="<?php echo e(route('logout')); ?>">Logout</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <?php if(session('notifikasi')): ?>
        <div class="toast-container position-absolute end-0 pe-3">
            <div class="toast show align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        <?php echo e(session('notifikasi')); ?>

                    </div>
                    <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>    
        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
<?php echo $__env->yieldPushContent('script'); ?>
</html><?php /**PATH D:\PROJECT LARAVEL\sidak\resources\views/layout.blade.php ENDPATH**/ ?>