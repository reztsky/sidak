
<?php $__env->startSection('link-dashboard','active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row my-3">
        <div class="col-md-12 col-sm-12 col-12 mb-3">
            <div class="bg-white border-2 border shadow-sm p-3 rounded">
                <h5 class="h5 fw-bold">Dashboard</h5>
                <hr>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th rowspan="2" class="text-center">Jabatan</th>
                                <th rowspan="2" class="text-center">Nama Kegiatan</th>
                                <th colspan="12" class="text-center">Bulan / <?php echo e(date('Y')); ?></th>
                            </tr>
                            <tr>
                                <?php $__currentLoopData = $bulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="text-center"><?php echo e($bulan); ?></th>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($row['jabatan_user']); ?></td>
                                    <td><?php echo e($row['nama_kegiatan']); ?></td>
                                    <?php $__currentLoopData = $bulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(array_key_exists($bulan,$row['details']->toArray())): ?>
                                        <td>
                                            <a href="<?php echo e(route('olahData.index',[
                                                'id_kegiatan'=>$row['id_kegiatan'],
                                                'bulan'=>$bulan,
                                                'tahun'=>date("Y")
                                            ])); ?>">
                                            <?php echo e($row['details'][$bulan]); ?>

                                            </a>
                                        </td>
                                        <?php else: ?>
                                            <td>-</td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\share-sultan\resources\views/content/dashboard.blade.php ENDPATH**/ ?>